//
//  AdGateMediaiOSSDK.h
//  AdGateMediaiOSSDK
//
//  Created by vishal dharnkar on 05/07/15.
//  Copyright (c) 2015 vishal dharnkar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AdGateMedia.h"

//! Project version number for AdGateMediaiOSSDK.
FOUNDATION_EXPORT double AdGateMediaiOSSDKVersionNumber;

//! Project version string for AdGateMediaiOSSDK.
FOUNDATION_EXPORT const unsigned char AdGateMediaiOSSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdGateMediaiOSSDK/PublicHeader.h>


